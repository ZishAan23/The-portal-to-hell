local newdecoder = require 'libraries/json/decoder'
local newencoder = require 'libraries/json/encoder'
local sax = require 'libraries/json/sax'
-- If you need multiple contexts of decoder and/or encoder,
-- you can require decoder and/or lunajson.encoder directly.
return {
	decode = newdecoder(),
	encode = newencoder(),
	newparser = sax.newparser,
	newfileparser = sax.newfileparser,
}
