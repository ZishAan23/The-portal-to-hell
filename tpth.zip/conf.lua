function love.conf(t)
  t.identity = nil
  t.version = "11.3.0"
  t.window.fullscreen = true
  t.window.width = 360
  t.window.height = 720
end