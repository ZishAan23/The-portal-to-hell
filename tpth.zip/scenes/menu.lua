local scene = {}
scene.__index = scene
scene.id = 1

function scene:load()
  require("../src/Ui/button")
  btn = button.new(10,30, 30, 15)
  btn.debug = true
  logo = love.graphics.newImage("/sprites/OxonLogo.png")
end

function scene:update(dt)
  btn:update(dt)
end

function scene:draw()
  love.graphics.setBackgroundColor(0, 0,0)
  love.graphics.setFont(defFont)
  
  love.graphics.print("play", 12,30)
  love.graphics.print("Music and Sprites by - Funanime", 12, 50)
  love.graphics.print("Programmed by - ZishAan23", 12, 67)
  love.graphics.draw(logo, 30, 80,0 , 0.1)
  btn:draw()
end

function scene:change()
  if btn:isClicked() then return true else return false end
end

return scene