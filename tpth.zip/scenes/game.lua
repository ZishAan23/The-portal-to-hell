local scene = {}
scene.__index = scene
scene.id = 2
  
function scene:load()
  require("../src/entities/player")
  require("../src/Ui/button")
  require("../src/Ui/D-pad")
  require("../src/Ui/dialogueBox")
  require("../src/entities/npc")
  
  tween = require("libraries/tween")
  json = require("libraries/json/lunajson")
  lume = require("libraries/lume")
  npcsJson = love.filesystem.read("json/npcs.json")
  npcsJson = json.decode(npcsJson)
  
  sti = require("libraries/sti")
  camera = require("libraries/camera")
  wf = require 'libraries/windfield'
  cam = camera(0,0, 2)
  world1 = wf.newWorld(0,0)
  map = sti("maps/map.lua")
  
  walls = {}
  if map.layers["Object Layer 1"] then
    for i,obj in pairs(map.layers["Object Layer 1"].objects) do
      wall = world1:newBSGRectangleCollider(obj.x,obj.y,obj.width,obj.height,1)
      wall:setType('static')
      table.insert(walls, wall)
    end
  end 
  
  Upbtn = button.new(75,205, 40,50)
  Downbtn = button.new(75,305, 40,50)
  Leftbtn = button.new(20,260,50,40)
  Rightbtn = button.new(120,260,50,40)
  act = button.new(550,270,65,65, "/sprites/Ui/chatButton.png", "/sprites/Ui/chatButtonPressed.png")
  act.mode = 1
  killBtn = button.new(630,240,65,65, "/sprites/Ui/killButton.png", "/sprites/Ui/killButtonPressed.png")
  killBtn.mode = 1
  chatBox = dialogueBox.new()
  btn1 = button.new(600,10,50,20)
  btn1.debug=true
  pad = dpad.new(30,200)
  
  plyr = player.new(-66,633, world1)
  killGraphics = {
    size=1,
    color={r=1,g=0,b=0,a=1}
  }
  killGraphicsTween = tween.new(1.5, killGraphics, {size = 500, color={r=1,g=0.1,b=0,a=0}})
  killGraphicsTween:set(1.5)
  
  npcs = {}
  for i,obj in pairs(npcsJson) do
    NPC = npc.new(obj.x, obj.y, obj.width, obj.height, obj.spritePath, obj.direction, world1, obj.text, obj.maxPage, obj.tombText, obj.tombId, obj.isSign)
    table.insert(npcs, NPC)
  end
  
  bgm = love.audio.newSource("/audios/townTheme.mp3", "stream")
  bgmKill = love.audio.newSource("/audios/killerTown.mp3", "stream")
  killSfx = love.audio.newSource("/audios/kill.wav", "static")
  bgm:setLooping(true)
  bgmKill:setLooping(true)
  bgmKill:setVolume(0)
  bgm:play()
  bgmKill:play()
  
  loadState()
  
end

time=0
function scene:update(dt)
  
  world1:update(dt)
  plyr:update(dt, Upbtn.clicked, Downbtn.clicked, Leftbtn.clicked, Rightbtn.clicked)
  for i,obj in pairs(npcs) do 
    obj:update(dt)
    distX = obj.x - plyr.x
    distY = obj.y - plyr.y
    distX = distX*distX
    distY = distY*distY
    distance = math.sqrt(distX + distY)
    if distance < obj.height*1.5 and act.clicked then
      if not obj.isKilled then
        chatBox:show(obj.text, obj.maxPage)
      else
        chatBox:show(obj.tombText, 1)
      end
    end
    if distance < obj.height*1.5 and killBtn.clicked and not chatBox.visible and not obj.isKilled and not obj.isSign then
      obj.isKilled = true
      time=0
      bgmKill:setVolume(1)
      bgm:setVolume(0)
      killGraphicsTween:reset()
      killSfx:play()
    end
  end
  
  killGraphicsTween:update(dt)

  if bgm:getVolume() < 1 then 
    time = time+1
    plyr.speed = 75
  end
  if time>100*15 then 
    time=0
    bgm:setVolume(1)
    bgmKill:setVolume(0)
    plyr.speed = 60
  end
  
  Upbtn:update(dt)
  Downbtn:update(dt)
  Leftbtn:update(dt)
  Rightbtn:update(dt)
  btn1:update(dt)
  pad:update(dt, Upbtn.clicked, Downbtn.clicked, Leftbtn.clicked, Rightbtn.clicked)
  act:update()
  killBtn:update()
  
  cam:lookAt(plyr.x, plyr.y)
  
--  if act.clicked then
 --  chatBox:show(dialogues.npc1[1], dialogues.npc1[2]) 
 -- end
end

function scene:draw()
  love.graphics.setBackgroundColor(143/255, 186/255, 82/255)
  love.graphics.setFont(defFont)
  
  cam:attach()
    map:drawLayer(map.layers["Tile Layer 5"])
    map:drawLayer(map.layers["Tile Layer 1"])
    map:drawLayer(map.layers["Tile Layer 4"])
    map:drawLayer(map.layers["Tile Layer 2"])
    map:drawLayer(map.layers["Tile Layer 3"])
    for i,obj in pairs(npcs) do
      obj:draw()
      distX = obj.x - plyr.x
      distY = obj.y - plyr.y
      distX = distX*distX
      distY = distY*distY
      distance = math.sqrt(distX + distY)
      if obj.isKilled and distance < obj.height*1.5 then 
        love.graphics.setColor(killGraphics.color.r, killGraphics.color.g, killGraphics.color.b, killGraphics.color.a)
        love.graphics.circle("fill",obj.x, obj.y, killGraphics.size, killGraphics.size)
        love.graphics.setColor(1,1,1,1)
      end
    end
    plyr:draw()
    map:drawLayer(map.layers["Tile Layer 6"])
   -- map:drawLayer(map.layers["Tile Layer 7"])
    
    
   -- world1:draw()
  cam:detach()
  
  love.graphics.print("Credits",602,10)
  Upbtn:draw()
  Downbtn:draw()
  Leftbtn:draw()
  Rightbtn:draw()
  btn1:draw()
  act:draw()
  killBtn:draw()
  pad:draw()
  chatBox:draw()
end

function love.quit()
  saveState()
end

function love.focus(f)
  if f==false then saveState() end
end

function scene:change()
  if btn1:isClicked() then 
    bgm:stop()
    bgmKill:stop()
    saveState()
    return true
  else
   return false 
  end
end

function saveState()
  data = {}
  data.player = {
    x = plyr.x,
    y = plyr.y,
    direction = plyr.direction
  }
  data.npcs = {}
  for i,obj in ipairs(npcs) do
    npcdat = {isKilled = obj.isKilled}
    table.insert(data.npcs, npcdat)
  end
  
  serialized = lume.serialize(data)
  love.filesystem.write("saveState.txt", serialized)
end

function loadState()
  if love.filesystem.getInfo("saveState.txt") then
    file = love.filesystem.read("saveState.txt")
    data = lume.deserialize(file)
    plyr.collider:setX(data.player.x)
    plyr.collider:setY(data.player.y)
    plyr.direction = data.player.direction
    
    for i,obj in ipairs(data.npcs) do
      npcs[i].isKilled = data.npcs[i].isKilled
    end
  end
end

return scene