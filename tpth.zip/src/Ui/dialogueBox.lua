dialogueBox = {}
dialogueBox.__index = dialogueBox 

function dialogueBox.new()
  local instance = setmetatable({}, dialogueBox)
  instance.visible = false
  instance.page = 0
  instance.maxPage = 1
  instance.font = love.graphics.newFont(18)
  instance.font:setLineHeight(1.7)
  instance.text = love.graphics.newText(instance.font)
  instance.sprite = love.graphics.newImage("/sprites/Ui/chatBox.png")
  return instance
end

function dialogueBox:draw()
  if self.visible then 
    love.graphics.setFont(self.font)
    love.graphics.draw(self.sprite, 0,0)
    
    love.graphics.setScissor(5,10,715,58)
    love.graphics.setColor(0,0,0)
    love.graphics.draw(self.text, 7.5,-72*self.page+10)
    love.graphics.setColor(1,1,1)
    love.graphics.setScissor()
  end
end

function dialogueBox:show(text, mxPg)
  
  if not self.visible then
    self.visible = true
    self.maxPage = mxPg
    self.text:setf(text, 710, "left")
  else
    self.page = self.page + 1
  end
  if self.page > self.maxPage-1 then 
    self.visible = false
    self.page = 0
  end
end

