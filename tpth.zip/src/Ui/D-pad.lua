dpad = {}
dpad.__index = dpad

function dpad.new(posX, posY)
  local instance = setmetatable({}, dpad)
  instance.sprite = love.graphics.newImage("/sprites/D-pad/dpadBase.png")
  instance.up = love.graphics.newImage("/sprites/D-pad/dpadUp.png")
  instance.down = love.graphics.newImage("/sprites/D-pad/dpadDown.png")
  instance.left = love.graphics.newImage("/sprites/D-pad/dpadLeft.png")
  instance.right = love.graphics.newImage("/sprites/D-pad/dpadRight.png")
  instance.base = love.graphics.newImage("/sprites/D-pad/dpadBase.png")
  instance.x = posX
  instance.y = posY
  return instance
end

function dpad:update(dt, up, down, left, right)
  if up then
    self.sprite = self.up
  elseif down then
    self.sprite = self.down
  elseif left then 
    self.sprite = self.left
  elseif right then
    self.sprite = self.right
  else
    self.sprite = self.base
  end
end

function dpad:draw()
  love.graphics.draw(self.sprite, self.x, self.y,0, 0.15, 0.15, 200,100)
end