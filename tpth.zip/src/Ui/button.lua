button = {}
button.__index = button

function button.new(posX, posY, width, height, btnSpr, prsdSpr)
  local instance = setmetatable({}, button)
  instance.x = posX
  instance.y = posY
  instance.width = width or 0
  instance.height = height or 0
  instance.clicked = false
  instance.debug = false
  instance.mode = 0
  instance.onceTouched = false
  instance.t = 0
  instance.btnSprite = nil
  instance.prsdSprite = nil
  
  if btnSpr and prsdSpr then
    instance.btnSprite = love.graphics.newImage(btnSpr)
    instance.prsdSprite = love.graphics.newImage(prsdSpr)
  end
  
  return instance
end

function button:update(dt)
  if self.mode == 0 then 
    if self:isClicked() then
      self.clicked = true
    else
      self.clicked = false
    end
  elseif self.mode == 1 then
    self.t = self.t+1
    if self:isClicked() and self.t>25 then
      self.t=0
      self.clicked = true
    else
      self.clicked = false
    end 
  end
end

function button:draw()
  if self:isClicked() then
    if self.debug then love.graphics.rectangle("fill", self.x , self.y, self.width, self.height) end
  else
    if self.debug then love.graphics.rectangle("line", self.x , self.y, self.width, self.height,nil,nil,10) end
  end
  if self.btnSprite and self.prsdSprite then
    if self:isClicked() then
      love.graphics.draw(self.prsdSprite, self.x, self.y,nil,0.05)
    else 
      love.graphics.draw(self.btnSprite, self.x, self.y,nil,0.05)
    end
  end
end

function button:isClicked()
  t = love.touch.getTouches()
  for i, id in ipairs(t) do
    local tx, ty = love.touch.getPosition(id)
    if tx<self.x+self.width and tx>self.x and ty<self.y+self.height and ty>self.y then
      return true
    else
      return false
    end
  end
end