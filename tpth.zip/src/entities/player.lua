player = {}
player.__index = player

function player.new(posX, posY, worl)
  anim8 = require("/libraries/anim8")
  wf = require 'libraries/windfield'
  world1 = worl
  
  local instance = setmetatable({}, player)
  instance.x = posX
  instance.y = posY
  instance.vx = 0
  instance.vy = 0
  instance.direction = 0
  instance.speed = 60
  instance.isMoving = false
  instance.walkAnimSpd = 0.125

  instance.sprite = love.graphics.newImage("/sprites/playerSheet.png")
  instance.grid = anim8.newGrid(15,21, instance.sprite:getWidth(), instance.sprite:getHeight())
  instance.animations = {}
  
  instance.animations.down = anim8.newAnimation(instance.grid('1-4', 1), instance.walkAnimSpd)
  instance.animations.up = anim8.newAnimation(instance.grid('1-4', 2), instance.walkAnimSpd)
  instance.animations.left = anim8.newAnimation(instance.grid('1-4', 4), instance.walkAnimSpd)
  instance.animations.right = anim8.newAnimation(instance.grid('1-4', 3), instance.walkAnimSpd)
  
  instance.animations.idleDown = anim8.newAnimation(instance.grid('1-2',5), 0.75)
  instance.animations.idleUp = anim8.newAnimation(instance.grid('3-4',5), 0.75)
  instance.animations.idleRight = anim8.newAnimation(instance.grid('1-2',6), 0.75)
  instance.animations.idleLeft = anim8.newAnimation(instance.grid('3-4',6), 0.75)
  
  instance.animation = instance.animations.idleDown
  
  world1:addCollisionClass("player")
  instance.collider = world1:newBSGRectangleCollider(instance.x, instance.y,14,14,2)
  instance.collider:setFixedRotation(true)
  instance.collider:setCollisionClass("player")
  
  return instance
end

function player:update(dt, up, down, left, right)
  if up then
    self.vy = -self.speed
    self.animation = self.animations.up
    isMoving = true
    self.direction = 1
    self.vx = 0
  elseif down then
    self.vy = self.speed
    self.animation = self.animations.down
    isMoving = true
    self.direction = 2
    self.vx = 0
  elseif left then
    self.vx = -self.speed
    self.animation = self.animations.left
    isMoving = true
    self.direction = 3
    self.vy = 0
  elseif right then 
    self.vx = self.speed
    self.animation = self.animations.right
    isMoving = true
    self.direction = 4
    self.vy = 0
  else
    isMoving = false
    self.vx = 0
    self.vy = 0
  end
  if chatBox.visible == true then
    self.vx = 0
    self.vy = 0
  end
  if isMoving == false then
    if self.direction == 1 then
      self.animation = self.animations.idleUp
    elseif self.direction == 2 then
      self.animation = self.animations.idleDown
    elseif self.direction == 3 then
      self.animation = self.animations.idleLeft
    else 
      self.animation = self.animations.idleRight
    end
  end
  self.animation:update(dt)
  
  self.x = self.collider:getX()
  self.y = self.collider:getY()-6
  self.collider:setLinearVelocity(self.vx, self.vy)
end

function player:draw()
  self.animation:draw(self.sprite, self.x, self.y, nil , 1, 1, 7.5, 10.5)
end