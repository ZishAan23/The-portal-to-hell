npc = {}
npc.__index = npc

function npc.new(posX, posY, w, h, sprPath, dir, worl, txt, pg, tombTxt, tombId, isSign)
  anim8 = require("/libraries/anim8")
  
  local instance = setmetatable({}, npc)
  instance.x = posX
  instance.y = posY
  instance.width = w
  instance.height = h
  instance.text = txt
  instance.tombText = tombTxt
  instance.maxPage = pg
  instance.isKilled = false
  instance.isSign = isSign
  
  instance.direction = dir
  instance.sprite = love.graphics.newImage(sprPath)
  instance.tombSheet = love.graphics.newImage("/sprites/tombSheet.png")
  instance.tombSprite = love.graphics.newQuad(tombId*15,0,15,17,instance.tombSheet)
  instance.grid = anim8.newGrid(instance.width, instance.height, instance.sprite:getWidth(), instance.sprite:getHeight())
  instance.animations = {}
  if not isSign==true then
   instance.animations.idle = anim8.newAnimation(instance.grid('1-2',instance.direction+1), 0.75)
  else
    instance.animations.idle = anim8.newAnimation(instance.grid('1-1', instance.direction+1),0.75)
  end
  
  instance.animation = instance.animations.idle
  
  instance.collider = worl:newBSGRectangleCollider(instance.x, instance.y, instance.width, instance.height,2)
  instance.collider:setType("static")
  
  instance.x = instance.collider:getX()
  instance.y = instance.collider:getY()
  return instance
end

function npc:update(dt, action)
  self.animation:update(dt)
end

function npc:draw()
  if not self.isKilled then
    self.animation:draw(self.sprite, self.x, self.y, nil, 1,1,self.width/2,self.height/2)
  else
    love.graphics.draw(self.tombSheet,self.tombSprite, self.x,self.y,nil,1,1,7.5,8.5)
  end
end
